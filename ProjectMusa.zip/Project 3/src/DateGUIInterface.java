
public interface DateGUIInterface {//An interface in the Java programming language is an abstract type that is used to specify a behavior that classes must implement.
	public void FileRead(String File);
}
