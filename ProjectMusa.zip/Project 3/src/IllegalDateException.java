
@SuppressWarnings("serial")
public class IllegalDateException extends IllegalArgumentException {

public IllegalDateException (String D) {
	super(D);

}
}
