/***************************************************************
 * 
 * @author Musa Tijani
 * A program that Takes Dates from file, Printed out in the GUI 
 *
 */

public class Project3 {
	public static void main(String[] args) throws Exception
	{
	 new DateGUI("Date.txt");
	}
	}
