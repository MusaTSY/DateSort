
public class UnsortedDate212List extends Date212List{
/** default*/
	public UnsortedDate212List() {
		super();//calls the parent constructor with no arguments.
	}
	public void add(Date212 date) {
		super.append(date);//calls the parent constructor with Date212 arguments.
	}
	public String toString() {
		return super.toString();
	}
}
